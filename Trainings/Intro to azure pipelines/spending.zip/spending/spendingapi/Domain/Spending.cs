namespace spendingapi.Domain
{
    public class Spending
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
    }
}